<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Asegúrate de que la ruta sea correcta

include 'connection.php'; // Asegúrate de que este archivo establece la conexión a la base de datos

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);

    // Verificar si la conexión a la base de datos se ha establecido correctamente
    if (!$conn) {
        die("Error de conexión a la base de datos.");
    }

    // Verificar si el correo electrónico existe en la base de datos
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Generar un token de restablecimiento de contraseña
        $token = bin2hex(random_bytes(50));
        $stmt = $conn->prepare("UPDATE users SET reset_token = :token, reset_token_expiry = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE email = :email");
        $stmt->bindParam(':token', $token);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        // Configurar PHPMailer para enviar el correo electrónico de restablecimiento de contraseña
        $mail = new PHPMailer(true);
        try {
            // Configuración del servidor
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'chipyblue0370@gmail.com'; // Tu dirección de correo de Gmail
            $mail->Password = 'hxnf zxmh eutu mcla'; // Tu contraseña de Gmail o contraseña de aplicación
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            // Configuración del correo electrónico
            $mail->setFrom('chipyblue0370@gmail.com', 'Administrador');
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = 'Restablecimiento de contraseña';
            $mail->Body = 'Haz clic en el siguiente enlace para restablecer tu contraseña: <a href="http://localhost/recetas_copia/reset_password.php?token=' . $token . '">Restablecer contraseña</a>';

            $mail->send();
            echo 'Se ha enviado un enlace de restablecimiento de contraseña a tu correo electrónico.';
            // Redirigir después de 5 segundos
            header("refresh:5;url=forgot_password.php");
        } catch (Exception $e) {
            echo 'Error al enviar el correo electrónico de restablecimiento de contraseña: ', $mail->ErrorInfo;
        }
    } else {
        echo 'No se encontró ninguna cuenta con ese correo electrónico.';
        // Redirigir después de 5 segundos
        header("refresh:5;url=forgot_password.php");
    }
}
?>