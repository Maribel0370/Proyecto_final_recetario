<?php
include 'connection.php';

// Verificar si una sesión ya está activa
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Obtener el ID del usuario
$user_id = $_SESSION['user_id'];

try {
    // Iniciar una transacción
    $conn->beginTransaction();

    // Obtener las recetas del usuario
    $sql = "SELECT id, image, video FROM recipes WHERE created_by = :user_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();
    $recipes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Eliminar los ingredientes asociados a las recetas del usuario en la tabla recipe_ingredients
    $sql = "DELETE FROM recipe_ingredients WHERE recipe_id IN (SELECT id FROM recipes WHERE created_by = :user_id)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();

    // Eliminar los comentarios asociados a las recetas del usuario
    $sql = "DELETE FROM comments WHERE recipe_id IN (SELECT id FROM recipes WHERE created_by = :user_id)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();

    // Eliminar los likes asociados a las recetas del usuario
    $sql = "DELETE FROM likes WHERE recipe_id IN (SELECT id FROM recipes WHERE created_by = :user_id)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();

    // Eliminar las recetas del usuario
    $sql = "DELETE FROM recipes WHERE created_by = :user_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();

    // Eliminar las imágenes y videos asociados a las recetas del usuario
    foreach ($recipes as $recipe) {
        if (!empty($recipe['image']) && file_exists('uploads/images/' . $recipe['image'])) {
            unlink('uploads/images/' . $recipe['image']);
        }
        if (!empty($recipe['video']) && file_exists('uploads/videos/' . $recipe['video'])) {
            unlink('uploads/videos/' . $recipe['video']);
        }
    }

    // Eliminar el perfil del usuario
    $sql = "DELETE FROM users WHERE id = :user_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();

    // Confirmar la transacción
    $conn->commit();

    // Destruir la sesión y redirigir al usuario a la página de inicio
    session_destroy();
    header('Location: index.php');
    exit;
} catch (Exception $e) {
    // Revertir la transacción en caso de error
    $conn->rollBack();
    echo "Error al eliminar el perfil: " . $e->getMessage();
}
?>
