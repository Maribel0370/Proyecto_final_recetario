<?php
// Iniciar la sesión solo si no está iniciada previamente
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="icons/favicon_logo.ico" type="image/x-icon"> <!-- Añadir favicon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Font Awesome -->
    <link rel="stylesheet" type="text/css" href="css/styles.css"> <!-- Archivo de estilos -->
    <title>Recetario Vegano</title> <!-- Updated title -->
</head>
<body>
    <header style="display: flex; align-items: center; justify-content: space-between;"> <!-- Centered vertically -->
        <!-- Logo de la página -->
        <div class="logo-container">
            <a href="index.php">
                <img src="img/logo_4.png" alt="Logo de la página" class="logo" style="width: 50px; height: auto;"> <!-- Smaller logo -->
            </a>
        </div>
        <!-- Menú de navegación -->
        <nav class="<?php echo isset($_SESSION['user_id']) ? 'nav-logged-in' : 'nav-logged-out'; ?>">
            <ul>
                <li><a href="index.php">Inicio</a></li>
                <li><a href="all_recipes.php">Recetas</a></li>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li><a href="profile.php">Perfil</a></li> <!-- Enlace al perfil -->
                <?php else: ?>
                    <li><a href="register.php">Registro</a></li> <!-- Enlace a registro si no está logueado -->
                <?php endif; ?>
            </ul>
        </nav>

        <!-- Formulario de login o enlace a perfil -->
        <?php if (!isset($_SESSION['user_id'])): ?>
            <!-- Mostrar login y registro si no hay sesión -->
            <div class="login-container" style="display: flex; align-items: center; margin-top:-75px; "> <!-- Centered vertically within header -->
                <form action="login_action.php" method="POST" id="loginForm" style="display: flex; align-items: center; width: 100%; max-width: 400px; margin: 0 auto;">
                    <div class="input-container" style="flex: 1; margin-right: 5px;">
                        <input type="text" name="username" id="username" placeholder="Usuario" required class="login-input" style="width: 100%; padding: 5px;">
                    </div>

                    <div class="password-container" style="flex: 1; position: relative;">
                        <input type="password" name="password" id="password" placeholder="Contraseña" required class="login-input" style="width: 100%; padding: 5px; padding-right: 40px;">
                        <span class="toggle-password" style="position: absolute; right: 10px; top: 60%; transform: translateY(-50%); cursor: pointer;">
                            <i class="fas fa-eye"></i> <!-- Ícono para mostrar/ocultar contraseña -->
                        </span>
                        <button type="submit" class="login-button" style="background: none; border: none; cursor: pointer; position: absolute; right: -40px; top: 70%; transform: translateY(-50%);">
                            <i class="fas fa-sign-in-alt"></i> <!-- Sign-in icon -->
                        </button>
                    </div>
                </form>
                <p style="margin-top: 15px;"><a href="forgot_password.php">¿He olvidado la contraseña?</a></p>
            </div>
        <?php else: ?>
            <!-- Mostrar perfil si hay sesión -->
            <div class="user-info">
                <span class="username"><?php echo htmlspecialchars($_SESSION['username'] ?? ''); ?></span>
                <form action="logout.php" method="POST" class="logout">
                    <button type="submit" style="background: none; border: none; cursor: pointer;">
                        <img src="icons/salida-de-emergencia.png" alt="Cerrar sesión" class="logout-icon">
                    </button>
                </form>
            </div>
        <?php endif; ?>
    </header>

    <!-- Script para mostrar/ocultar contraseña -->
    <script>
        const togglePasswordButtons = document.querySelectorAll('.toggle-password');

        togglePasswordButtons.forEach(toggle => {
            toggle.addEventListener('click', () => {
                const passwordField = toggle.previousElementSibling;

                // Cambia el tipo de input entre 'password' y 'text'
                if (passwordField.type === 'password') {
                    passwordField.type = 'text';
                    toggle.innerHTML = '<i class="fas fa-eye-slash"></i>'; // Ícono de ojo tachado
                } else {
                    passwordField.type = 'password';
                    toggle.innerHTML = '<i class="fas fa-eye"></i>'; // Ícono de ojo
                }
            });
        });
    </script>
</body>
</html>     