<?php
include 'connection.php';

// Verificar si una sesión ya está activa
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Verificar si la receta existe y pertenece al usuario
if (isset($_GET['id'])) {
    $recipe_id = $_GET['id'];
    $user_id = $_SESSION['user_id'];

    $sql = "SELECT * FROM recipes WHERE id = :id AND created_by = :user_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id', $recipe_id);
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();
    $recipe = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($recipe) {
        // Eliminar archivos asociados a la receta (imágenes y videos)
        if (!empty($recipe['image']) && file_exists('uploads/images/' . $recipe['image'])) {
            unlink('uploads/images/' . $recipe['image']);
        }
        if (!empty($recipe['video']) && file_exists('uploads/videos/' . $recipe['video'])) {
            unlink('uploads/videos/' . $recipe['video']);
        }

        // Eliminar los ingredientes asociados a la receta en la tabla recipe_ingredients
        $sql = "DELETE FROM recipe_ingredients WHERE recipe_id = :recipe_id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':recipe_id', $recipe_id);
        $stmt->execute();

        // Eliminar los comentarios asociados a la receta
        $sql = "DELETE FROM comments WHERE recipe_id = :recipe_id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':recipe_id', $recipe_id);
        $stmt->execute();

        // Eliminar la receta de la base de datos
        $sql = "DELETE FROM recipes WHERE id = :id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id', $recipe_id);
        $stmt->execute();

        // Redirigir a la página de perfil con un mensaje de éxito
        header('Location: profile.php?recipe_deleted=1');
        exit;
    } else {
        // Si no se encuentra la receta o no pertenece al usuario
        header('Location: profile.php?error=recipe_not_found');
        exit;
    }
}
?>
