<?php
include 'header.php';
include 'connection.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
?>

<head>
    <title>Crear Receta</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>

<body>
    <div class="profile-container">
        <h1>Crear Receta</h1>
        <form id="recipe-form" action="create_recipe_action.php" method="post" enctype="multipart/form-data">
            <label for="title">Título:</label>
            <input type="text" id="title" name="title" required>

            <label for="description">Descripción:</label>
            <textarea id="description" name="description" required></textarea>

            <label for="category">Categoría:</label>
            <select name="category" id="category" onchange="toggleIngredientField()" required>
                <option value="Vegano">Vegano</option>
                <option value="Intolerante">Intolerante</option>
                <option value="Alergeno">Alergeno</option>
            </select>

            <div id="ingredient-field" style="display: none;">
                <label for="ingredient">Ingrediente (Intolerancia/Alergia):</label>
                <input type="text" id="ingredient" name="ingredient">
            </div>

            <label for="type">Tipo de receta:</label>
            <select name="type" id="type" required>
                <option value="desayuno">Desayuno</option>
                <option value="comida">Comida</option>
                <option value="cena">Cena</option>
                <option value="postre">Postre</option>
                <option value="aperitivo">Aperitivo</option>
                <option value="snack">Snack</option>
            </select>

            <label for="ingredients">Ingredientes:</label>
            <div id="ingredients-container">
                <div class="ingredient">
                    <input type="text" name="ingredients[][name]" placeholder="Ingrediente" required>
                    <input type="text" name="ingredients[][quantity]" placeholder="Cantidad" required>
                </div>
                <button type="button" id="add-ingredient">Agregar Ingrediente</button>
            </div>

            <label for="instructions">Instrucciones:</label>
            <textarea id="instructions" name="instructions" required></textarea>

            <label for="image">Imagen:</label>
            <input type="file" id="image" name="image">

            <label for="video">Video:</label>
            <input type="file" id="video" name="video">

            <button type="submit">Crear Receta</button>
        </form>
    </div>

    <script>
        function toggleIngredientField() {
            const category = document.getElementById('category').value;
            document.getElementById('ingredient-field').style.display = (category === 'Intolerante' || category === 'Alergeno') ? 'block' : 'none';
        }

        document.getElementById('add-ingredient').addEventListener('click', () => {
            const container = document.getElementById('ingredients-container');
            const newIngredient = document.createElement('div');
            newIngredient.classList.add('ingredient');
            newIngredient.innerHTML = `
                <input type="text" name="ingredients[][name]" placeholder="Ingrediente" required>
                <input type="text" name="ingredients[][quantity]" placeholder="Cantidad" required>
            `;
            container.appendChild(newIngredient);
        });

        function capitalizeFirstLetter(text) {
            return text.replace(/(?:^|\.\s*)([a-z])/g, function(match, p1) {
                return match.replace(p1, p1.toUpperCase());
            });
        }

        document.getElementById('recipe-form').addEventListener('submit', function(event) {
            const title = document.getElementById('title');
            const description = document.getElementById('description');
            const instructions = document.getElementById('instructions');

            title.value = capitalizeFirstLetter(title.value);
            description.value = capitalizeFirstLetter(description.value);
            instructions.value = capitalizeFirstLetter(instructions.value);

            const ingredientNames = document.querySelectorAll('input[name="ingredients[][name]"]');
            ingredientNames.forEach(input => {
                input.value = capitalizeFirstLetter(input.value);
            });
        });

        toggleIngredientField(); // Inicializar el estado del campo de ingrediente
    </script>
</body>
<?php include 'footer.php'; ?>
</html>