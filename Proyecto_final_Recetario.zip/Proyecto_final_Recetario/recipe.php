<?php 
include 'header.php';
include 'connection.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$recipe_id = $_GET['id'] ?? null;

if (!$recipe_id) {
    echo "Receta no encontrada.";
    exit;
}

// Obtener la receta y los ingredientes actuales
$sql = "SELECT recipes.*, users.username FROM recipes 
        JOIN users ON recipes.created_by = users.id 
        WHERE recipes.id = :recipe_id";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':recipe_id', $recipe_id, PDO::PARAM_INT);
$stmt->execute();
$recipe = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$recipe) {
    die("Receta no encontrada.");
}

// Incrementar el contador de vistas en la tabla recipes
$updateViewsSql = "UPDATE recipes SET views = views + 1 WHERE id = :recipe_id";
$updateViewsStmt = $conn->prepare($updateViewsSql);
$updateViewsStmt->bindParam(':recipe_id', $recipe_id, PDO::PARAM_INT);
$updateViewsStmt->execute();

// Registrar la vista en la tabla views
$insertViewSql = "INSERT INTO views (recipe_id, user_id) VALUES (:recipe_id, :user_id)";
$insertViewStmt = $conn->prepare($insertViewSql);
$insertViewStmt->bindParam(':recipe_id', $recipe_id, PDO::PARAM_INT);
$insertViewStmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$insertViewStmt->execute();

// Obtener los ingredientes asociados a la receta
$sql_ingredients = "SELECT ri.quantity, i.name 
                    FROM recipe_ingredients ri 
                    INNER JOIN ingredients i ON ri.ingredient_id = i.id 
                    WHERE ri.recipe_id = :recipe_id";
$stmt_ingredients = $conn->prepare($sql_ingredients);
$stmt_ingredients->bindParam(':recipe_id', $recipe_id, PDO::PARAM_INT);
$stmt_ingredients->execute();
$ingredients = $stmt_ingredients->fetchAll(PDO::FETCH_ASSOC);

// Obtener la intolerancia asociada a la receta
$sql_intolerance = "SELECT intolerance FROM recipe_intolerances WHERE recipe_id = :recipe_id";
$stmt_intolerance = $conn->prepare($sql_intolerance);
$stmt_intolerance->bindParam(':recipe_id', $recipe_id, PDO::PARAM_INT);
$stmt_intolerance->execute();
$intolerance = $stmt_intolerance->fetchColumn();

// Obtener los comentarios de la receta
$query_comments = "SELECT comments.*, users.username FROM comments 
                   JOIN users ON comments.user_id = users.id 
                   WHERE comments.recipe_id = :recipe_id ORDER BY comments.created_at DESC";
$stmt_comments = $conn->prepare($query_comments);
$stmt_comments->bindParam(':recipe_id', $recipe_id, PDO::PARAM_INT);
$stmt_comments->execute();
$comments = $stmt_comments->fetchAll(PDO::FETCH_ASSOC);

// Manejar el envío de comentarios
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['comment'])) {
    $comment = $_POST['comment'];
    $user_id = $_SESSION['user_id'] ?? null;

    if ($user_id && $comment) {
        $query_insert_comment = "INSERT INTO comments (recipe_id, user_id, comment, created_at) VALUES (:recipe_id, :user_id, :comment, NOW())";
        $stmt_insert_comment = $conn->prepare($query_insert_comment);
        $stmt_insert_comment->bindParam(':recipe_id', $recipe_id, PDO::PARAM_INT);
        $stmt_insert_comment->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt_insert_comment->bindParam(':comment', $comment, PDO::PARAM_STR);
        $stmt_insert_comment->execute();
        header("Location: recipe.php?id=$recipe_id");
        exit;
    }
}

// Manejar el "me gusta" y "quitar me gusta"
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['like'])) {
    $user_id = $_SESSION['user_id'] ?? null;

    if ($user_id) {
        $query_check_like = "SELECT * FROM likes WHERE recipe_id = :recipe_id AND user_id = :user_id";
        $stmt_check_like = $conn->prepare($query_check_like);
        $stmt_check_like->bindParam(':recipe_id', $recipe_id, PDO::PARAM_INT);
        $stmt_check_like->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt_check_like->execute();
        $like = $stmt_check_like->fetch(PDO::FETCH_ASSOC);

        if ($like) {
            $query_unlike = "DELETE FROM likes WHERE recipe_id = :recipe_id AND user_id = :user_id";
            $stmt_unlike = $conn->prepare($query_unlike);
            $stmt_unlike->bindParam(':recipe_id', $recipe_id, PDO::PARAM_INT);
            $stmt_unlike->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmt_unlike->execute();
        } else {
            $query_like = "INSERT INTO likes (recipe_id, user_id) VALUES (:recipe_id, :user_id)";
            $stmt_like = $conn->prepare($query_like);
            $stmt_like->bindParam(':recipe_id', $recipe_id, PDO::PARAM_INT);
            $stmt_like->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmt_like->execute();
        }
        header("Location: recipe.php?id=$recipe_id");
        exit;
    }
}

// Contar los "me gusta"
$query_likes = "SELECT COUNT(*) as like_count FROM likes WHERE recipe_id = :recipe_id";
$stmt_likes = $conn->prepare($query_likes);
$stmt_likes->bindParam(':recipe_id', $recipe_id, PDO::PARAM_INT);
$stmt_likes->execute();
$like_count = $stmt_likes->fetchColumn();

// Verificar si el usuario actual ha dado "me gusta"
$query_user_like = "SELECT * FROM likes WHERE recipe_id = :recipe_id AND user_id = :user_id";
$stmt_user_like = $conn->prepare($query_user_like);
$stmt_user_like->bindParam(':recipe_id', $recipe_id, PDO::PARAM_INT);
$stmt_user_like->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmt_user_like->execute();
$user_like = $stmt_user_like->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($recipe['title']); ?></title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        .media-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }

        .media-item {
            flex: 1 1 300px;
            max-width: 100%;
        }

        .recipe-image, .recipe-video {
            width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <div class="recipe-container">
        <h1><?php echo htmlspecialchars($recipe['title']); ?></h1>
        <p><strong>Descripción:</strong> <?php echo nl2br(htmlspecialchars($recipe['description'])); ?></p>
        <p><strong>Categoría:</strong> <?php echo htmlspecialchars($recipe['category']); ?></p>
        <p><strong>Tipo de receta:</strong> <?php echo htmlspecialchars($recipe['type']); ?></p>
        <p><strong>Creado por:</strong> <?php echo htmlspecialchars($recipe['username']); ?></p>
        <p><strong>Instrucciones:</strong> <?php echo nl2br(htmlspecialchars($recipe['instructions'])); ?></p>

        <?php if ($intolerance): ?>
            <p><strong>Intolerancia:</strong> <?php echo htmlspecialchars($intolerance); ?></p>
        <?php endif; ?>

        <h2>Ingredientes</h2>
        <ul>
            <?php foreach ($ingredients as $ingredient): ?>
                <li><?php echo htmlspecialchars($ingredient['name']) . ": " . htmlspecialchars($ingredient['quantity']); ?></li>
            <?php endforeach; ?>
        </ul>

        <div class="media-container">
            <div class="media-item">
                <h2>Imagen</h2>
                <?php if (!empty($recipe['image'])): ?>
                    <img src="<?php echo htmlspecialchars($recipe['image']); ?>" alt="Imagen de la receta" class="recipe-image">
                <?php else: ?>
                    <p>No hay imagen disponible.</p>
                <?php endif; ?>
            </div>

            <div class="media-item">
                <h2>Video</h2>
                <?php if (!empty($recipe['video'])): ?>
                    <video controls class="recipe-video">
                        <source src="<?php echo htmlspecialchars($recipe['video']); ?>" type="video/mp4">
                        Tu navegador no soporta la reproducción de videos.
                    </video>
                <?php else: ?>
                    <p>No hay video disponible.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Sección de "Me gusta" -->
        <form action="recipe.php?id=<?php echo $recipe_id; ?>" method="POST">
            <button type="submit" name="like"><?php echo $user_like ? 'Quitar Me gusta' : 'Me gusta'; ?></button> <span><?php echo $like_count; ?> Me gusta</span>
        </form>

        <!-- Sección de comentarios -->
        <h2>Comentarios</h2>
        <?php if (isset($_SESSION['user_id'])): ?>
            <form action="recipe.php?id=<?php echo $recipe_id; ?>" method="POST">
                <textarea name="comment" rows="4" placeholder="Escribe un comentario..." required></textarea>
                <button type="submit">Enviar</button>
            </form>
        <?php else: ?>
            <p>Para dejar un comentario, <a href="index.php">inicia sesión</a>.</p>
        <?php endif; ?>

        <?php if (!empty($comments)): ?>
            <div class="comments-list">
                <?php foreach ($comments as $comment): ?>
                    <div class="comment-item">
                        <p><strong><?php echo htmlspecialchars($comment['username']); ?>:</strong> <?php echo nl2br(htmlspecialchars($comment['comment'])); ?></p>
                        <p><small><?php echo htmlspecialchars($comment['created_at']); ?></small></p>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p>No hay comentarios aún.</p>
        <?php endif; ?>

        <?php if (!isset($_SESSION['user_id'])): ?>
            <p>Para ver la receta completa, <a href="login.php">inicia sesión</a>.</p>
        <?php endif; ?>
    </div>

    <?php include 'footer.php'; ?>
</body>
</html>