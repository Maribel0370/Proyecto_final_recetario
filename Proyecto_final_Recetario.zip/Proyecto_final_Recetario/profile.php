<?php
include 'header.php';
include 'connection.php';

// Verificar si una sesión ya está activa
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Obtener la información del usuario
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = :user_id";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':user_id', $user_id);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Obtener las recetas del usuario
$sql_recipes = "SELECT * FROM recipes WHERE created_by = :user_id";
$stmt_recipes = $conn->prepare($sql_recipes);
$stmt_recipes->bindParam(':user_id', $user_id);
$stmt_recipes->execute();
$recipes = $stmt_recipes->fetchAll(PDO::FETCH_ASSOC);
?>

<head>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
    <title>Perfil de Usuario</title>
</head>
<body>
    <div class="recipes-container">
        <div class="profile-container">
            <h1>Perfil de Usuario</h1>
            <p>Nombre de usuario: <?php echo htmlspecialchars($user['username']); ?></p>
            <p>Correo electrónico: <?php echo htmlspecialchars($user['email']); ?></p>
            <!-- Opción Cambiar Contraseña -->
            <div>
                <a href="change_password.php">Cambiar Contraseña</a>
            </div>
            <!-- Opción para eliminar el perfil -->
            <div>
                <a href="delete_profile.php" style="color: red;" onclick="return confirm('¿Estás seguro de que quieres eliminar tu perfil? Esto eliminará todas tus recetas y datos asociados de manera permanente.');">Eliminar mi perfil</a>
            </div>
        </div>

        <!-- Mensaje de éxito o error si es necesario -->
        <?php if (isset($_GET['recipe_deleted']) && $_GET['recipe_deleted'] == '1'): ?>
            <div class="alert alert-success">La receta ha sido eliminada exitosamente.</div>
        <?php endif; ?>

        <?php if (isset($_GET['error']) && $_GET['error'] == 'recipe_not_found'): ?>
            <div class="alert alert-danger">No se encontró la receta o no es de tu propiedad.</div>
        <?php endif; ?>

        <!-- Mostrar las recetas del usuario -->
        <div class="user-recipes">
            <h2>Mis Recetas</h2>
            <?php if (!empty($recipes)): ?>
                <ul>
                    <?php foreach ($recipes as $recipe): ?>
                        <li>
                            <?php echo htmlspecialchars($recipe['title']); ?> - 
                            <a href="edit_recipe.php?id=<?php echo $recipe['id']; ?>">Editar</a> | 
                            <a href="delete_recipe.php?id=<?php echo $recipe['id']; ?>" onclick="return confirm('¿Estás seguro de que quieres eliminar esta receta?');">Eliminar</a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>No has creado recetas aún.</p>
            <?php endif; ?>
            <a href="create_recipe.php">Crear Nueva Receta</a>
        </div>
    </div>
</body>
<?php include 'footer.php'; ?>
</html>