-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-11-2024 a las 22:37:51
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `recetas_culinarias`
--
CREATE DATABASE IF NOT EXISTS `recetas_culinarias` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `recetas_culinarias`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipe_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `rating` int(11) DEFAULT NULL CHECK (`rating` between 1 and 5),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `recipe_id` (`recipe_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `comments`
--

INSERT INTO `comments` (`id`, `recipe_id`, `user_id`, `comment`, `rating`, `created_at`) VALUES
(1, 4, 3, 'Que ricos que están\r\n', NULL, '2024-11-14 20:00:14'),
(2, 4, 2, 'Tiene muy buena pinta', NULL, '2024-11-16 11:43:12'),
(3, 6, 2, 'Qué rico.\r\n\r\n', NULL, '2024-11-16 11:48:27'),
(4, 6, 2, 'Qué rico.\r\n\r\n', NULL, '2024-11-16 11:48:29'),
(5, 8, 9, 'Muy ricas, buen desayuno.', NULL, '2024-11-23 00:25:06'),
(6, 6, 9, '👍', NULL, '2024-11-23 13:45:17');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ingredients`
--

DROP TABLE IF EXISTS `ingredients`;
CREATE TABLE IF NOT EXISTS `ingredients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `allergens` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ingredients`
--

INSERT INTO `ingredients` (`id`, `name`, `allergens`) VALUES
(1, 'macarrones', NULL),
(2, 'tomate', NULL),
(3, 'seitan', NULL),
(4, 'queso vegano', NULL),
(5, 'Espaguetis', NULL),
(6, 'Pimiento rojo', NULL),
(7, 'Berenjena', NULL),
(8, 'Pasta de colores', NULL),
(9, 'Perejil', NULL),
(10, 'aceite de oliva', NULL),
(11, 'Sal', NULL),
(12, 'Pimienta', NULL),
(13, '', NULL),
(14, 'Gluten', NULL),
(15, 'Array', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `likes`
--

DROP TABLE IF EXISTS `likes`;
CREATE TABLE IF NOT EXISTS `likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `recipe_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `recipe_id` (`recipe_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `likes`
--

INSERT INTO `likes` (`id`, `user_id`, `recipe_id`) VALUES
(6, 3, 4),
(7, 3, 6),
(8, 2, 4),
(9, 2, 6),
(11, 9, 6),
(12, 9, 8);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recipes`
--

DROP TABLE IF EXISTS `recipes`;
CREATE TABLE IF NOT EXISTS `recipes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `instructions` longtext DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `allergy_type` varchar(255) DEFAULT NULL,
  `intolerance` varchar(255) DEFAULT NULL,
  `views` int(11) DEFAULT 0,
  `likes` int(11) DEFAULT 0,
  `type` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `allergens` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `recipes`
--

INSERT INTO `recipes` (`id`, `title`, `description`, `instructions`, `category`, `created_by`, `created_at`, `image`, `video`, `allergy_type`, `intolerance`, `views`, `likes`, `type`, `user_id`, `allergens`) VALUES
(4, 'macarrones boloñesa', 'Para 2 personas', 'Cocer los macarrones. Después hacer la boloñesa con soja texturizada previamente hidratada.', 'Vegano ', 2, '2024-11-22 22:07:28', 'uploads/images/macarrones-a-la-bolonesa.jpeg', 'uploads/videos/macarrones_boloñesa_vegana.mp4', NULL, NULL, 8, 0, 'comida', NULL, NULL),
(5, 'Espaguetis boloñesa', 'Espaguetis para veganos', 'Cocer los espaguetis, hacer la salsa con la soja texturizada', 'Vegano', 3, '2024-11-22 19:27:31', 'uploads/images/spaguetis boloñesa.jpeg', 'uploads/videos/spaguetis_boloñesa_vegana.mp4', NULL, NULL, 18, 0, 'comida', NULL, NULL),
(6, 'Ensalada de pasta con berenjenas y pimientos asados', 'Ingredientes: (para 2 personas)', 'Asar el pimiento y la berenjena al horno (unos 20-25 minutos), al fuego (unos 10\r\nminutos) o en el microondas (15-20 minutos). Envolverlos en papel de periódico y\r\ncuando estén fríos quitar la piel a mano.\r\nHervir la pasta en agua con sal, escurrir y dejar enfriar.\r\nMezclar la pasta con el pimiento y la berenjena troceados. Añadir un puñado de perejil\r\npicado y un chorrito de oliva.\r\nPuede tomarse frío o caliente, como os guste más.', 'Alergeno', 2, '2024-09-01 10:09:52', 'uploads/images/ensalada_pasta_colores.jpg', 'uploads/videos/ensalada_pasta_colores.mp4', 'Gluten', NULL, 1009, 0, 'Vegano', NULL, NULL),
(7, 'Ensalada de lentejas', 'Para 4 personas', 'Se cuecen las lentejas, se pica el tomate junto con la cebolla y el resto de ingredientes para la ensalada. Se añade una cucharadita de aceite, limón o vinagre de manzana al gusto, sal al gusto', 'Intolerante', 2, '2024-11-22 18:58:23', 'uploads/images/Ensalada_Lentejas.jpeg', 'uploads/videos/Ensalada_lentejas.mp4', 'Gluten', 'Gluten', 23, 10, 'Comida', NULL, 'Gluten'),
(8, 'Arepas', 'Desayuno saludable a base de arena de maíz.', '1. Dividimos la masa en ocho porciones del peso/tamaño más parecido posible y hacemos una bola con cada una de ellas. Después las aplastamos y les damos forma redondeada. Como las vamos a rellenar, dejamos cada arepa de un dedo de grosor (unos 1.5 cm). Si no fuera el caso, las podríamos dejar más finas.\r\n\r\n2. Calentamos una sartén o plancha antiadherente y cocemos en ella las arepas. Mantenemos una temperatura media (5 de 9 en mi placa de inducción) para que las arepas se cuezan bien por dentro y no queden crudas.\r\n\r\n3.Cocemos durante 8-10 minutos por una cara, volteamos y cocemos otros 8-10 minutos por la otra. Tenemos que ir mirando que adquieran cierto color dorado por el exterior y que no se quemen. Si se tuestan demasiado, bajamos la intensidad del calor. Si, por el contrario, tardan mucho en dorarse, subimos un poco el fuego.\r\n\r\n4.Cuando las arepas estén en su punto, las introducimos en el horno y las mantenemos calientes a 100º C. Así mantendrán el crujiente exterior. Repetimos el proceso con el resto de arepas hasta que estén todas hechas.', 'Vegano', 9, '2024-11-17 10:01:13', 'uploads/images/673ef410f050d_arepas_veganas_75645_orig-transformed.jpeg', 'uploads/videos/67412298cb4ce_Arepas Venezolanas _ Sin Gluten, Veganas.mp4', NULL, 'Lactosa', 619, 0, 'desayuno', NULL, 'Para intolerantes a la Lactosa'),
(9, 'Receta 1', 'Descripción 1', NULL, NULL, NULL, '2024-11-22 15:14:28', NULL, NULL, NULL, NULL, 5, 0, NULL, NULL, NULL),
(10, 'Receta 2', 'Descripción 2', NULL, NULL, NULL, '2024-11-21 15:14:28', NULL, NULL, NULL, NULL, 50, 0, NULL, NULL, NULL),
(11, 'Receta 3', 'Descripción 3', NULL, NULL, NULL, '2024-11-15 15:14:28', NULL, NULL, NULL, NULL, 150, 0, NULL, NULL, NULL),
(12, 'Receta 4', 'Descripción 4', NULL, NULL, NULL, '2024-10-22 14:14:28', NULL, NULL, NULL, NULL, 10, 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recipe_allergens`
--

DROP TABLE IF EXISTS `recipe_allergens`;
CREATE TABLE IF NOT EXISTS `recipe_allergens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipe_id` int(11) DEFAULT NULL,
  `allergen` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recipe_id` (`recipe_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `recipe_allergens`
--

INSERT INTO `recipe_allergens` (`id`, `recipe_id`, `allergen`) VALUES
(1, 6, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recipe_ingredients`
--

DROP TABLE IF EXISTS `recipe_ingredients`;
CREATE TABLE IF NOT EXISTS `recipe_ingredients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipe_id` int(11) DEFAULT NULL,
  `ingredient_id` int(11) DEFAULT NULL,
  `quantity` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recipe_id` (`recipe_id`),
  KEY `ingredient_id` (`ingredient_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `recipe_ingredients`
--

INSERT INTO `recipe_ingredients` (`id`, `recipe_id`, `ingredient_id`, `quantity`) VALUES
(27, NULL, 1, '100 gr'),
(28, NULL, 2, '1000 gr'),
(29, NULL, 3, '300 gr'),
(30, NULL, 4, '100 gr'),
(31, 6, 6, '1'),
(32, 6, 7, '1'),
(33, 6, 8, '250 gr'),
(34, 6, 9, 'Un puñado'),
(35, 6, 10, '1 cda.'),
(36, 6, 11, '1 cdta.'),
(37, 6, 12, '1 cdta.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recipe_intolerances`
--

DROP TABLE IF EXISTS `recipe_intolerances`;
CREATE TABLE IF NOT EXISTS `recipe_intolerances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipe_id` int(11) NOT NULL,
  `intolerance` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `recipe_id` (`recipe_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `reset_token` varchar(255) NOT NULL,
  `reset_token_expiry` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `created_at`, `reset_token`, `reset_token_expiry`) VALUES
(2, 'Maria', 'chipyblue0370@gmail.com', '$2y$10$UQKbZQsjlF4C4cSAPx1GVeoNLgNgE9kNSf3Px.0jdW8HPYS..s26O', '2024-11-10 07:06:51', 'eb16389378024747a0aa40282d5091be02d57d78b0279d3486b7adb9214aec2bd55cd97699379ece40b9129f0689e250a629', '2024-11-23 11:26:38'),
(3, 'Maribel', 'maviburbujita@gmail.com', '$2y$10$.KLYdtRASfkM5DPyU/FIXOavfoOws2iTu.Sg.HRlEb2RQmW4bh8XG', '2024-11-10 17:25:23', '', NULL),
(5, 'Ahora_no', 'mgarro0370@gmail.com', '$2y$10$6Vubgnli5U06FQS8KJyzW.x3mGCbphieFFvf5LyRa9HAv8ePB/6p6', '2024-11-14 19:23:00', '', NULL),
(6, 'Dos_veces', 'soalar20@gmail.com', '$2y$10$Q1/Gcs85fQi2V0y5/hYjkOgdMaX58XVkPFtKafpnSyzXqfL7XyMyq', '2024-11-14 19:27:21', '', NULL),
(7, 'Mikel', 'ibilbaodiaz@gmail.com', '$2y$10$.WBixlULhaeNXSqpGdkJvOa1fX0Bj2gGltxsou4fICvSIiYbfyNze', '2024-11-16 13:25:08', '', NULL),
(8, 'anapat', 'anasoyyo@gmail.com', '$2y$10$W1BKUm1EVnVqwjzIB9TvJOdmfzDhKZq6c1o.Aw3Vqw2tFp9akO9au', '2024-11-16 15:05:44', '', NULL),
(9, 'Khris', 'khrisgomez@gmail.com', '$2y$10$C7DCchHNWiuFs7KM.KVNx.PtpbIIGLfphsGsqlORE6mBw8Od94oSm', '2024-11-17 09:51:03', '', NULL),
(10, 'TestFer', 'ferzk98@gmail.com', '$2y$10$oDHItZiT78rO4AuvpBmcCevmHbhYmhK5kAj3Hr.rtmCbw6sxfihce', '2024-11-17 11:43:27', '', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `views`
--

DROP TABLE IF EXISTS `views`;
CREATE TABLE IF NOT EXISTS `views` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipe_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `view_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `recipe_id` (`recipe_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `views`
--

INSERT INTO `views` (`id`, `recipe_id`, `user_id`, `view_date`) VALUES
(1, 8, 9, '2024-11-21 23:42:26'),
(2, 8, 9, '2024-11-22 00:06:35'),
(3, 7, 9, '2024-11-22 00:06:54'),
(4, 6, 9, '2024-11-22 00:07:05'),
(5, 6, 3, '2024-11-22 11:38:20'),
(6, 7, 3, '2024-11-22 11:38:27'),
(7, 6, 3, '2024-11-22 11:38:33'),
(8, 7, 3, '2024-11-22 11:40:31'),
(9, 7, 3, '2024-11-22 11:40:40'),
(10, 7, 3, '2024-11-22 12:30:58'),
(11, 6, 3, '2024-11-22 12:31:06'),
(12, 7, 3, '2024-11-22 12:31:13'),
(13, 6, 3, '2024-11-22 12:31:23'),
(14, 6, 9, '2024-11-22 21:10:12'),
(15, 6, 9, '2024-11-22 22:45:36'),
(16, 8, 9, '2024-11-22 22:45:48'),
(17, 8, 9, '2024-11-22 22:46:24'),
(18, 8, 9, '2024-11-22 23:00:50'),
(19, 8, 9, '2024-11-22 23:01:39'),
(20, 8, 9, '2024-11-22 23:02:03'),
(21, 8, 3, '2024-11-22 23:22:02'),
(22, 5, 3, '2024-11-22 23:23:09'),
(23, 5, 3, '2024-11-22 23:23:28'),
(24, 8, 9, '2024-11-22 23:24:02'),
(25, 5, 3, '2024-11-22 23:26:06'),
(26, 5, NULL, '2024-11-22 23:28:42'),
(27, 5, NULL, '2024-11-22 23:30:39'),
(28, 5, NULL, '2024-11-22 23:30:39'),
(29, 5, NULL, '2024-11-22 23:30:51'),
(30, 5, NULL, '2024-11-22 23:30:51'),
(31, 5, NULL, '2024-11-22 23:32:05'),
(32, 6, NULL, '2024-11-23 00:24:01'),
(33, 6, NULL, '2024-11-23 00:24:12'),
(34, 6, NULL, '2024-11-23 00:24:13'),
(35, 8, NULL, '2024-11-23 00:24:30'),
(36, 8, NULL, '2024-11-23 00:24:42'),
(37, 8, NULL, '2024-11-23 00:24:42'),
(38, 8, NULL, '2024-11-23 00:25:06'),
(39, 8, NULL, '2024-11-23 00:25:06'),
(40, 8, NULL, '2024-11-23 00:32:25'),
(41, 8, NULL, '2024-11-23 00:32:31'),
(42, 6, NULL, '2024-11-23 13:44:41'),
(43, 6, NULL, '2024-11-23 13:45:17'),
(44, 6, NULL, '2024-11-23 13:45:17'),
(45, 8, NULL, '2024-11-23 13:46:13'),
(46, 6, NULL, '2024-11-23 14:07:21'),
(47, 8, NULL, '2024-11-23 14:15:34'),
(48, 7, NULL, '2024-11-23 15:04:38'),
(49, 7, NULL, '2024-11-23 15:25:26'),
(50, 4, NULL, '2024-11-23 15:36:52'),
(51, 4, NULL, '2024-11-23 15:38:47'),
(52, 4, NULL, '2024-11-23 15:38:49'),
(53, 8, NULL, '2024-11-23 15:41:13'),
(54, 8, NULL, '2024-11-23 15:41:25'),
(55, 5, NULL, '2024-11-23 15:49:51'),
(56, 8, NULL, '2024-11-23 21:19:25');

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `likes`
--
ALTER TABLE `likes`
  ADD CONSTRAINT `likes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `likes_ibfk_2` FOREIGN KEY (`recipe_id`) REFERENCES `recipes` (`id`);

--
-- Filtros para la tabla `recipes`
--
ALTER TABLE `recipes`
  ADD CONSTRAINT `recipes_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `recipe_allergens`
--
ALTER TABLE `recipe_allergens`
  ADD CONSTRAINT `recipe_allergens_ibfk_1` FOREIGN KEY (`recipe_id`) REFERENCES `recipes` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `recipe_ingredients`
--
ALTER TABLE `recipe_ingredients`
  ADD CONSTRAINT `recipe_ingredients_ibfk_1` FOREIGN KEY (`recipe_id`) REFERENCES `recipes` (`id`),
  ADD CONSTRAINT `recipe_ingredients_ibfk_2` FOREIGN KEY (`ingredient_id`) REFERENCES `ingredients` (`id`);

--
-- Filtros para la tabla `recipe_intolerances`
--
ALTER TABLE `recipe_intolerances`
  ADD CONSTRAINT `recipe_intolerances_ibfk_1` FOREIGN KEY (`recipe_id`) REFERENCES `recipes` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `views`
--
ALTER TABLE `views`
  ADD CONSTRAINT `views_ibfk_1` FOREIGN KEY (`recipe_id`) REFERENCES `recipes` (`id`),
  ADD CONSTRAINT `views_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
