<?php
include 'connection.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $recipe_id = $_POST['recipe_id'];

    // Verificar si el usuario ya ha dado like a la receta
    $sql = "SELECT * FROM likes WHERE recipe_id = :recipe_id AND user_id = :user_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':recipe_id', $recipe_id);
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();

    if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
        // Agregar el like a la receta
        $sql = "INSERT INTO likes (recipe_id, user_id) VALUES (:recipe_id, :user_id)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':recipe_id', $recipe_id);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
    }

    // Redirigir de nuevo a la página de la receta
    header('Location: recipe.php?id=' . $recipe_id);
    exit;
}
?>