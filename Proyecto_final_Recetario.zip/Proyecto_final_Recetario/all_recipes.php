<?php 
include 'connection.php'; 
include 'header.php'; 

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Obtener los parámetros de la búsqueda
$query = $_GET['query'] ?? '';
$filter = $_GET['filter'] ?? '';
$allergen = $_GET['allergen'] ?? '';
$type = $_GET['type'] ?? '';

// Construir la consulta SQL para las recetas
$sql = "SELECT recipes.*, users.username FROM recipes 
        JOIN users ON recipes.created_by = users.id 
        WHERE recipes.title LIKE ?";

// Parámetro de búsqueda por título
$params = ["%$query%"];

// Filtrar por categoría (Vegano)
if ($filter == 'vegan') {
    $sql .= " AND recipes.category LIKE ?";
    $params[] = "%Vegano%";
}

// Filtrar por alérgenos o intolerancias
if ($filter == 'allergen' || $filter == 'intolerant') {
    $stmt = $conn->prepare("SELECT id FROM ingredients WHERE name = ?");
    $stmt->execute([$allergen]);
    $ingredient_id = $stmt->fetchColumn();

    if (!$ingredient_id) {
        $stmt = $conn->prepare("INSERT INTO ingredients (name) VALUES (?)");
        $stmt->execute([$allergen]);
        $ingredient_id = $conn->lastInsertId();
    }

    $sql .= " AND recipes.id IN (SELECT recipe_id FROM recipe_allergens WHERE allergen LIKE ?)";
    $params[] = "%$allergen%";
}

// Filtrar por tipo de receta
if (!empty($type)) {
    $sql .= " AND recipes.type LIKE ?";
    $params[] = "%$type%";
}

// Ejecutar la consulta
$stmt = $conn->prepare($sql);
$stmt->execute($params);
$recipes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Si no hay búsqueda, obtener todas las recetas ordenadas por las más recientes
if (empty($query)) {
    $query_latest = "SELECT recipes.*, users.username FROM recipes 
                     JOIN users ON recipes.created_by = users.id 
                     ORDER BY recipes.created_at DESC";
    $stmt_latest = $conn->prepare($query_latest);
    $stmt_latest->execute();
    $result_latest = $stmt_latest->fetchAll(PDO::FETCH_ASSOC);
}
?>

<head>
    <title>Todas las Recetas</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css">
</head>
<body>
    <div class="recipes-container">
        <h1>Todas las Recetas</h1>

        <!-- Formulario de búsqueda -->
        <form action="all_recipes.php" method="GET">
            <div class="form-field">
                <label for="query">Buscar:</label>
                <input type="text" name="query" id="query" value="<?php echo htmlspecialchars($query); ?>">
            </div>
            <div class="form-field">
                <label for="filter">Filtrar por:</label>
                <select name="filter" id="filter" onchange="toggleAllergenField()">
                    <option value="">Todos</option>
                    <option value="vegan" <?php echo ($filter == 'vegan') ? 'selected' : ''; ?>>Vegano</option>
                    <option value="allergen" <?php echo ($filter == 'allergen') ? 'selected' : ''; ?>>Alérgeno</option>
                    <option value="intolerant" <?php echo ($filter == 'intolerant') ? 'selected' : ''; ?>>Intolerancia</option>
                </select>
            </div>
            <div class="form-field" id="allergen-field" style="display: none;">
                <label for="allergen">Ingrediente (Intolerancia/Alergia):</label>
                <input type="text" name="allergen" id="allergen" value="<?php echo htmlspecialchars($allergen); ?>">
            </div>
            <div class="form-field">
                <label for="type">Tipo de receta:</label>
                <select name="type" id="type">
                    <option value="">Todos</option>
                    <option value="desayuno" <?php echo ($type == 'desayuno') ? 'selected' : ''; ?>>Desayuno</option>
                    <option value="comida" <?php echo ($type == 'comida') ? 'selected' : ''; ?>>Comida</option>
                    <option value="cena" <?php echo ($type == 'cena') ? 'selected' : ''; ?>>Cena</option>
                    <option value="postre" <?php echo ($type == 'postre') ? 'selected' : ''; ?>>Postre</option>
                    <option value="aperitivo" <?php echo ($type == 'aperitivo') ? 'selected' : ''; ?>>Aperitivo</option>
                    <option value="snack" <?php echo ($type == 'snack') ? 'selected' : ''; ?>>Snack</option>
                </select>
            </div>
            <button type="submit">Buscar</button>
        </form>

        <!-- Si no hay búsqueda, mostrar las recetas más recientes en un carrusel -->
        <?php if (empty($query)): ?>
            <?php if (count($result_latest) > 3): ?>
                <div class="recipe-carousel">
                    <?php foreach ($result_latest as $recipe): ?>
                        <div class="recipe-card">
                            <img src="<?php echo htmlspecialchars($recipe['image']); ?>" alt="Imagen de <?php echo htmlspecialchars($recipe['title']); ?>">
                            <h3><?php echo htmlspecialchars($recipe['title']); ?></h3>
                            <p><?php echo htmlspecialchars($recipe['description']); ?></p>
                            <p>Creado por: <?php echo htmlspecialchars($recipe['username'] ?? ''); ?></p>
                            <a href="<?php echo isset($_SESSION['user_id']) ? 'recipe.php?id=' . $recipe['id'] : 'index.php'; ?>">Ver receta completa</a>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="recipes-list">
                    <?php foreach ($result_latest as $recipe): ?>
                        <div class="recipe-item">
                            <img src="<?php echo htmlspecialchars($recipe['image']); ?>" alt="Imagen de <?php echo htmlspecialchars($recipe['title']); ?>">
                            <h3><a href="<?php echo isset($_SESSION['user_id']) ? 'recipe.php?id=' . $recipe['id'] : 'index.php'; ?>"><?php echo htmlspecialchars($recipe['title']); ?></a></h3>
                            <p>Categoría: <?php echo htmlspecialchars($recipe['category']); ?></p>
                            <p>Tipo: <?php echo htmlspecialchars($recipe['type']); ?></p>
                            <p>Creado por: <?php echo htmlspecialchars($recipe['username'] ?? ''); ?></p>
                            <a href="<?php echo isset($_SESSION['user_id']) ? 'recipe.php?id=' . $recipe['id'] : 'index.php'; ?>">Ver receta completa</a>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <!-- Mostrar las recetas de la búsqueda en un carrusel si hay más de tres recetas -->
            <?php if (count($recipes) > 3): ?>
                <div class="recipe-carousel">
                    <?php foreach ($recipes as $recipe): ?>
                        <div class="recipe-card">
                            <img src="<?php echo htmlspecialchars($recipe['image']); ?>" alt="Imagen de <?php echo htmlspecialchars($recipe['title']); ?>">
                            <h3><?php echo htmlspecialchars($recipe['title']); ?></h3>
                            <p><?php echo htmlspecialchars($recipe['description']); ?></p>
                            <p>Creado por: <?php echo htmlspecialchars($recipe['username'] ?? ''); ?></p>
                            <a href="<?php echo isset($_SESSION['user_id']) ? 'recipe.php?id=' . $recipe['id'] : 'index.php'; ?>">Ver receta completa</a>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="recipes-list">
                    <?php foreach ($recipes as $recipe): ?>
                        <div class="recipe-item">
                            <img src="<?php echo htmlspecialchars($recipe['image']); ?>" alt="Imagen de <?php echo htmlspecialchars($recipe['title']); ?>">
                            <h3><a href="<?php echo isset($_SESSION['user_id']) ? 'recipe.php?id=' . $recipe['id'] : 'index.php'; ?>"><?php echo htmlspecialchars($recipe['title']); ?></a></h3>
                            <p>Categoría: <?php echo htmlspecialchars($recipe['category']); ?></p>
                            <p>Tipo: <?php echo htmlspecialchars($recipe['type']); ?></p>
                            <p>Creado por: <?php echo htmlspecialchars($recipe['username'] ?? ''); ?></p>
                            <a href="<?php echo isset($_SESSION['user_id']) ? 'recipe.php?id=' . $recipe['id'] : 'index.php'; ?>">Ver receta completa</a>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <!-- Slick Carousel Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
    <script>
        $(document).ready(function(){
            $('.recipe-carousel').slick({
                slidesToShow: 3,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 3000,
                dots: true,
                arrows: true,
            });
        });

        function toggleAllergenField() {
            const filter = document.getElementById('filter').value;
            document.getElementById('allergen-field').style.display = (filter === 'allergen' || filter === 'intolerant') ? 'block' : 'none';
        }
        toggleAllergenField();
    </script>
</body>
<?php include 'footer.php'; ?>
</html>
