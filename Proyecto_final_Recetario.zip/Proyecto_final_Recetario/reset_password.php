<?php
include 'header.php';
include 'connection.php'; // Asegúrate de que este archivo establece la conexión a la base de datos

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $token = $_POST['token'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if ($new_password !== $confirm_password) {
        $error = "Las contraseñas no coinciden.";
    } else {
        // Verificar si el token es válido y no ha expirado
        $stmt = $conn->prepare("SELECT * FROM users WHERE reset_token = :token AND reset_token_expiry > NOW()");
        $stmt->bindParam(':token', $token);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // Actualizar la contraseña del usuario
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET password = :password, reset_token = NULL, reset_token_expiry = NULL WHERE id = :id");
            $stmt->bindParam(':password', $hashed_password);
            $stmt->bindParam(':id', $user['id']);
            $stmt->execute();

            echo "Tu contraseña ha sido restablecida exitosamente.";
            // Redirigir después de 5 segundos
            header("refresh:5;url=login.php");
        } else {
            $error = "El enlace de restablecimiento de contraseña es inválido o ha expirado.";
        }
    }
} else {
    $token = $_GET['token'];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restablecer Contraseña</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
    <div class="main-container">
        <div class="register-container">
            <div class="form-container">
                <h1>Restablecer Contraseña</h1>
                <?php if (isset($error)): ?>
                    <div class="error-message"><?php echo $error; ?></div>
                <?php endif; ?>
                <form action="reset_password.php" method="POST">
                    <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                    <div class="form-field password-container">
                        <label for="new_password">Nueva Contraseña:</label>
                        <input type="password" name="new_password" id="new_password" required>
                        <span class="toggle-password" onclick="togglePasswordVisibility('new_password', this)">
                            <i class="fas fa-eye"></i>
                        </span>
                    </div>
                    <div class="form-field password-container">
                        <label for="confirm_password">Confirmar Contraseña:</label>
                        <input type="password" name="confirm_password" id="confirm_password" required>
                        <span class="toggle-password" onclick="togglePasswordVisibility('confirm_password', this)">
                            <i class="fas fa-eye"></i>
                        </span>
                    </div>
                    <button type="submit">Restablecer Contraseña</button>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Script para mostrar/ocultar contraseña
        function togglePasswordVisibility(id, toggleIcon) {
            const input = document.getElementById(id);
            const icon = toggleIcon.querySelector('i');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash'); // Cambiar a ícono de ojo tachado
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye'); // Cambiar a ícono de ojo
            }
        }
    </script>
</body>
<?php include 'footer.php'; ?>
</html>