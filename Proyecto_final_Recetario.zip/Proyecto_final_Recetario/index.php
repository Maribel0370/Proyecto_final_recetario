<?php 
include 'connection.php'; 
include 'header.php'; 

// Función para obtener las recetas más vistas sin repetir
function getTopRecipes($conn, $limit, $excludeIds = []) {
    try {
        $excludeCondition = '';
        if (!empty($excludeIds)) {
            $excludeCondition = 'AND id NOT IN (' . implode(',', array_map('intval', $excludeIds)) . ')';
        }
        $sql = "SELECT * FROM recipes WHERE views > 0 $excludeCondition ORDER BY views DESC LIMIT :limit";
        $stmt = $conn->prepare($sql);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error al obtener recetas: " . $e->getMessage());
        return [];
    }
}

// Obtener recetas del día, de la semana y del mes anterior sin que se repitan
$recipesOfTheDay = getTopRecipes($conn, 1);
$shownRecipes = array_column($recipesOfTheDay, 'id');

$recipesOfTheWeek = getTopRecipes($conn, 1, $shownRecipes);
$shownRecipes = array_merge($shownRecipes, array_column($recipesOfTheWeek, 'id'));

$recipesOfTheMonth = getTopRecipes($conn, 1, $shownRecipes);

// Obtener las tres últimas recetas para la página principal
$query_latest = "SELECT recipes.*, users.username FROM recipes 
                 JOIN users ON recipes.created_by = users.id 
                 ORDER BY recipes.created_at DESC LIMIT 3";
$result_latest = $conn->query($query_latest)->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Recetas para Veganos, Intolerancias y Alergias alimentarias">
    <meta name="keywords" content="Vegan Recipe, Recetas Veganas, Intolerance, Intolerancias, Allergens, Alergenos">
    <meta name="author" content="Cristian_Maribel">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css">
    <title>Recetario Vegano</title>
</head>
<body>
    <h1>Bienvenido a nuestra página de Recetas para Veganos, Intolerantes y Alérgicos</h1>  

    <div class="main-container">
        <div class="recipes-container">
            <div class="recipes-grid">
                <!-- Receta del Día -->
                <div class="recipe-column">
                    <div class="recipe-box">
                        <h2>Receta del Día</h2>
                        <?php if (!empty($recipesOfTheDay)): ?>
                            <div class="recipe-item">
                                <h3><?php echo htmlspecialchars($recipesOfTheDay[0]['title']); ?></h3>
                                <p><?php echo htmlspecialchars($recipesOfTheDay[0]['description']); ?></p>
                                <?php if (!empty($recipesOfTheDay[0]['image'])): ?>
                                    <img src="<?php echo htmlspecialchars($recipesOfTheDay[0]['image']); ?>" alt="<?php echo htmlspecialchars($recipesOfTheDay[0]['title']); ?>" class="recipe-image">
                                <?php else: ?>
                                    <p>Imagen no disponible.</p>
                                <?php endif; ?>
                                <?php if (isset($_SESSION['user_id'])): ?>
                                    <a href="recipe.php?id=<?php echo $recipesOfTheDay[0]['id']; ?>" class="btn view-recipe-btn">Ver Receta</a>
                                <?php else: ?>
                                    <p>Por favor, <a href="index.php#loginForm">inicia sesión</a> para continuar.</p>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <p>No hay recetas del día.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Receta de la Semana -->
                <div class="recipe-column">
                    <div class="recipe-box">
                        <h2>Receta de la Semana</h2>
                        <?php if (!empty($recipesOfTheWeek)): ?>
                            <div class="recipe-item">
                                <h3><?php echo htmlspecialchars($recipesOfTheWeek[0]['title']); ?></h3>
                                <p><?php echo htmlspecialchars($recipesOfTheWeek[0]['description']); ?></p>
                                <?php if (!empty($recipesOfTheWeek[0]['image'])): ?>
                                    <img src="<?php echo htmlspecialchars($recipesOfTheWeek[0]['image']); ?>" alt="<?php echo htmlspecialchars($recipesOfTheWeek[0]['title']); ?>" class="recipe-image">
                                <?php else: ?>
                                    <p>Imagen no disponible.</p>
                                <?php endif; ?>
                                <?php if (isset($_SESSION['user_id'])): ?>
                                    <a href="recipe.php?id=<?php echo $recipesOfTheWeek[0]['id']; ?>" class="btn view-recipe-btn">Ver Receta</a>
                                <?php else: ?>
                                    <p>Por favor, <a href="index.php#loginForm">inicia sesión</a> para continuar.</p>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <p>No hay recetas de la semana.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Receta del Mes -->
                <div class="recipe-column">
                    <div class="recipe-box">
                        <h2>Receta del Mes Anterior</h2>
                        <?php if (!empty($recipesOfTheMonth)): ?>
                            <div class="recipe-item">
                                <h3><?php echo htmlspecialchars($recipesOfTheMonth[0]['title']); ?></h3>
                                <p><?php echo htmlspecialchars($recipesOfTheMonth[0]['description']); ?></p>
                                <?php if (!empty($recipesOfTheMonth[0]['image'])): ?>
                                    <img src="<?php echo htmlspecialchars($recipesOfTheMonth[0]['image']); ?>" alt="<?php echo htmlspecialchars($recipesOfTheMonth[0]['title']); ?>" class="recipe-image">
                                <?php else: ?>
                                    <p>Imagen no disponible.</p>
                                <?php endif; ?>
                                <?php if (isset($_SESSION['user_id'])): ?>
                                    <a href="recipe.php?id=<?php echo $recipesOfTheMonth[0]['id']; ?>" class="btn view-recipe-btn">Ver Receta</a>
                                <?php else: ?>
                                    <p>Por favor, <a href="index.php#loginForm">inicia sesión</a> para continuar.</p>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <p>No hay recetas del mes anterior.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Enlace para crear una nueva receta -->
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="create_recipe.php" class="btn create-recipe-btn">Crear Nueva Receta</a>
            <?php endif; ?>
        </div>      
</body>
<?php include 'footer.php'; ?>
</html>
