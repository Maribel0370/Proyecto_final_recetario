<footer>
    <div class="footer-block">
        <h2>Contacto</h2>
         <p>
            <img src="icons/whatsapp.png" alt="Móvil" class="contact-icon"> Móvil: +34 123 456 789
         </p>
         <p>
            <img src="icons/gmail.png" alt="Email" class="contact-icon"> Email: info@recetas.com
         </p>
    </div>
    <div class="footer-block">
        <h2>Redes Sociales</h2>
         <p>
            <a href="https://www.facebook.com" target="_blank">
                <img src="icons/facebook.png" alt="Facebook" class="social-icon">
            </a>
            <a href="https://www.instagram.com" target="_blank">
                <img src="icons/instagram.png" alt="Instagram" class="social-icon">
            </a>
            <a href="https://www.twitter.com" target="_blank">
                <img src="icons/Twitter.png" alt="Twitter" class="social-icon">
            </a>
            <a href="https://www.tiktok.com" target="_blank">
                <img src="icons/tiktok.png" alt="TikTok" class="social-icon">
            </a>
         </p>
    </div>
    <div class="footer-block">
        <h2>Webs Amigas</h2>
        <p>
            <a href="https://www.webamiga1.com" target="_blank">Web Amiga 1</a><br>
            <a href="https://www.webamiga2.com" target="_blank">Web Amiga 2</a>
        </p>
    </div>
    <div class="footer-block">
        <h2>Localización</h2>
        <img src="icons/ubicacion.png" alt="Ubicacion" class="contact-icon">
        <p>Dirección: Calle Ejemplo 123, Ciudad, País</p>
    </div>
    <div class="footer-block">
        <p>&copy; <?php echo date("Y"); ?> Khristian y Maribel. Todos los derechos reservados.</p>
    </div>
</footer>
