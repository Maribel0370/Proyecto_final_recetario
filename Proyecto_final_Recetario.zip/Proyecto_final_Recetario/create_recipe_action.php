<?php
include 'connection.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $category = $_POST['category'];
    $type = $_POST['type'];
    $instructions = $_POST['instructions'];
    $ingredients = isset($_POST['ingredients']) ? $_POST['ingredients'] : [];
    $ingredient = $_POST['ingredient'] ?? '';

    // Manejo de la imagen
    $image_path = null;
    if (!empty($_FILES['image']['name'])) {
        $image = $_FILES['image'];
        $image_name = uniqid() . "_" . basename($image['name']);
        $upload_dir = 'uploads/images/';
        $upload_image_path = $upload_dir . $image_name;

        if (!move_uploaded_file($image['tmp_name'], $upload_image_path)) {
            die("Error al subir la imagen.");
        }
        $image_path = $upload_image_path;
    }

    // Manejo del video
    $video_path = null;
    if (!empty($_FILES['video']['name'])) {
        $video = $_FILES['video'];
        $video_name = uniqid() . "_" . basename($video['name']);
        $upload_video_path = 'uploads/videos/' . $video_name;

        if (!move_uploaded_file($video['tmp_name'], $upload_video_path)) {
            die("Error al subir el video.");
        }
        $video_path = $upload_video_path;
    }

    // Insertar receta
    $sql = "INSERT INTO recipes (title, description, category, type, instructions, image, video, created_by) VALUES (:title, :description, :category, :type, :instructions, :image, :video, :created_by)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':title', $title);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':category', $category);
    $stmt->bindParam(':type', $type);
    $stmt->bindParam(':instructions', $instructions);
    $stmt->bindParam(':image', $image_path);
    $stmt->bindParam(':video', $video_path);
    $stmt->bindParam(':created_by', $_SESSION['user_id']);
    $stmt->execute();
    $recipe_id = $conn->lastInsertId();

    // Insertar el ingrediente de intolerancia/alergia si existe
    if (!empty($ingredient)) {
        $stmt = $conn->prepare("SELECT id FROM ingredients WHERE name = ?");
        $stmt->execute([$ingredient]);
        $ingredient_id = $stmt->fetchColumn();

        if (!$ingredient_id) {
            $stmt = $conn->prepare("INSERT INTO ingredients (name) VALUES (?)");
            $stmt->execute([$ingredient]);
            $ingredient_id = $conn->lastInsertId();
        }

        $sql = "INSERT INTO recipe_intolerances (recipe_id, intolerance) VALUES (:recipe_id, :intolerance)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':recipe_id', $recipe_id);
        $stmt->bindParam(':intolerance', $ingredient);
        $stmt->execute();
    }

    // Insertar los ingredientes
    foreach ($ingredients as $ingredient) {
        if (!empty($ingredient['name']) && !empty($ingredient['quantity'])) {
            $name = $ingredient['name'];
            $quantity = $ingredient['quantity'];

            // Verificar si el ingrediente existe en la base de datos
            $sql = "SELECT id FROM ingredients WHERE name = :name";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':name', $name);
            $stmt->execute();
            $ingredient_id = $stmt->fetchColumn();

            if (!$ingredient_id) {
                // Si el ingrediente no existe, lo insertamos
                $sql = "INSERT INTO ingredients (name) VALUES (:name)";
                $stmt = $conn->prepare($sql);
                $stmt->bindParam(':name', $name);
                $stmt->execute();
                $ingredient_id = $conn->lastInsertId();
            }

            // Insertamos el ingrediente en la tabla de receta_ingredientes
            $sql = "INSERT INTO recipe_ingredients (recipe_id, ingredient_id, quantity) VALUES (:recipe_id, :ingredient_id, :quantity)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':recipe_id', $recipe_id);
            $stmt->bindParam(':ingredient_id', $ingredient_id);
            $stmt->bindParam(':quantity', $quantity);
            $stmt->execute();
        }
    }

    // Redireccionar a la página de la receta creada
    header('Location: recipe.php?id=' . $recipe_id);
    exit;
}
?>