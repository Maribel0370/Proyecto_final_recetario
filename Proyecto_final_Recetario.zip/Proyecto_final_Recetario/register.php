<?php 
include 'connection.php'; 
include 'header.php'; 

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') { 
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    $confirm_password = isset($_POST['confirm_password']) ? trim($_POST['confirm_password']) : '';

    if ($password !== $confirm_password) { 
        $error_message = "Las contraseñas no coinciden."; 
    } else {
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = :username OR email = :email"); 
        $stmt->execute(['username' => $username, 'email' => $email]); 

        if ($stmt->rowCount() > 0) { 
            $error_message = "El nombre de usuario o el correo electrónico ya están registrados."; 
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT); 
            $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (:username, :email, :password)"); 
            $stmt->execute(['username' => $username, 'email' => $email, 'password' => $hashed_password]); 
            
            header("Location: index.php");
            exit(); 
        }
    }
} 
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de usuario</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
    <h1>Registro de usuario</h1>
    <div class="main-container">
        <div class="register-container">
            <?php if ($error_message): ?>
                <div class="error-message"><?php echo $error_message; ?></div>
            <?php endif; ?>
            <form action="register.php" method="POST">
                <div class="form-field">
                    <label for="username">Nombre de usuario:</label>
                    <input type="text" name="username" id="username" required>
                </div>
                <div class="form-field">
                    <label for="email">Correo electrónico:</label>
                    <input type="email" name="email" id="email" required>
                </div>
                <div class="form-field">
                    <label for="password">Contraseña:</label>
                    <div class="password-container">
                        <input type="password" id="password" name="password" required>
                        <span class="toggle-password fa fa-eye"></span>
                    </div>
                </div>
                <div class="form-field">
                    <label for="confirm_password">Confirmar Contraseña:</label>
                    <div class="password-container">
                        <input type="password" id="confirm_password" name="confirm_password"  required>
                        <span class="toggle-password fa fa-eye"></span>
                    </div>
                </div>
                <button type="submit">Registrar</button>
                <p>¿Ya tienes una cuenta? <a href="index.php">Inicia sesión aquí</a>.</p>
            </form>
        </div>
    </div>

    <script src="js/register.js"></script>
</body>
<?php include 'footer.php'; ?>
</html>