<?php
include 'header.php';
include 'connection.php'; // Asegúrate de que este archivo establece la conexión a la base de datos

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Verificar si las contraseñas nuevas coinciden
    if ($new_password !== $confirm_password) {
        $error = "Las contraseñas no coinciden.";
    } else {
        // Verificar la contraseña actual
        $stmt = $conn->prepare("SELECT password FROM users WHERE id = :id");
        $stmt->bindParam(':id', $_SESSION['user_id']);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($current_password, $user['password'])) {
            // Actualizar la contraseña del usuario
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET password = :password WHERE id = :id");
            $stmt->bindParam(':password', $hashed_password);
            $stmt->bindParam(':id', $_SESSION['user_id']);
            $stmt->execute();

            echo "Tu contraseña ha sido cambiada exitosamente.";
            // Redirigir después de 5 segundos
            header("refresh:5;url=profile.php");
        } else {
            $error = "La contraseña actual es incorrecta.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cambiar Contraseña</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
    <div class="main-container">
        <div class="register-container">
            <div class="form-container">
                <h1>Cambiar Contraseña</h1>
                <?php if (isset($error)): ?>
                    <div class="error-message"><?php echo $error; ?></div>
                <?php endif; ?>
                <form action="change_password.php" method="POST">
                    <div class="form-field password-container">
                        <label for="current_password">Contraseña Actual:</label>
                        <input type="password" name="current_password" id="current_password" required>
                        <span class="toggle-password" onclick="togglePasswordVisibility('current_password', this)">
                            <i class="fas fa-eye"></i>
                        </span>
                    </div>
                    <div class="form-field password-container">
                        <label for="new_password">Nueva Contraseña:</label>
                        <input type="password" name="new_password" id="new_password" required>
                        <span class="toggle-password" onclick="togglePasswordVisibility('new_password', this)">
                            <i class="fas fa-eye"></i>
                        </span>
                    </div>
                    <div class="form-field password-container">
                        <label for="confirm_password">Confirmar Nueva Contraseña:</label>
                        <input type="password" name="confirm_password" id="confirm_password" required>
                        <span class="toggle-password" onclick="togglePasswordVisibility('confirm_password', this)">
                            <i class="fas fa-eye"></i>
                        </span>
                    </div>
                    <button type="submit">Cambiar Contraseña</button>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Script para mostrar/ocultar contraseña
        function togglePasswordVisibility(id, toggleIcon) {
            const input = document.getElementById(id);
            const icon = toggleIcon.querySelector('i');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash'); // Cambiar a ícono de ojo tachado
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye'); // Cambiar a ícono de ojo
            }
        }
    </script>
</body>
<?php include 'footer.php'; ?>
</html>