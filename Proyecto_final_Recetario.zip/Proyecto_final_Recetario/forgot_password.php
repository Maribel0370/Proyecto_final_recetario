<?php
include 'header.php';
include 'connection.php';
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Contraseña</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
    <div class="main-container">
        <div class="register-container">
            <div class="form-container">
                <h1>Recuperar Contraseña</h1>
                <form action="send_password_reset.php" method="POST">
                    <div class="form-field">
                        <label for="email">Correo electrónico:</label>
                        <input type="email" name="email" id="email" required>
                    </div>
                    <button type="submit">Enviar Enlace de Restablecimiento</button>
                </form>
            </div>
        </div>
    </div>
</body>
<?php include 'footer.php'; ?>
</html>