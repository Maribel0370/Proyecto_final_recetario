<?php
include 'connection.php'; 
include 'header.php'; 

// Verificar si el usuario está logueado
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$username = trim($_POST['username']);
$password = trim($_POST['password']);

// Validar que el nombre de usuario no esté vacío
if (empty($username)) {
    echo "El nombre de usuario no puede estar vacío.";
    exit;
}

// Verificar si el nombre de usuario ya existe en otro usuario
$stmt = $conn->prepare("SELECT id FROM users WHERE username = :username AND id != :user_id");
$stmt->execute(['username' => $username, 'user_id' => $user_id]);

if ($stmt->rowCount() > 0) {
    echo "El nombre de usuario ya está en uso por otro usuario.";
    exit;
}

// Actualizar nombre de usuario
$update_data = ['username' => $username, 'user_id' => $user_id];
$query = "UPDATE users SET username = :username";

if (!empty($password)) {
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $query .= ", password = :password";
    $update_data['password'] = $hashed_password;
}

$query .= " WHERE id = :user_id";

try {
    $stmt = $conn->prepare($query);
    $stmt->execute($update_data);
    header("Location: profile.php");
    exit;
} catch (PDOException $e) {
    echo "Error al actualizar el perfil: " . $e->getMessage();
}

include 'footer.php';
?>


