<?php
include 'connection.php'; 
include 'header.php'; 

// Verificar que el usuario esté autenticado
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Procesar el formulario de comentarios
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $recipe_id = $_POST['recipe_id'];
    $comment = $_POST['comment'];
    $user_id = $_SESSION['user_id'];

    // Insertar el comentario en la base de datos
    $stmt = $conn->prepare("INSERT INTO comments (recipe_id, user_id, comment) VALUES (?, ?, ?)");
    $stmt->execute([$recipe_id, $user_id, $comment]);

    // Redirigir de vuelta a la receta
    header("Location: all_recipes.php");
    exit;
}

include 'footer.php';
?>