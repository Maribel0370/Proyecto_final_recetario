<?php
include 'header.php';
include 'connection.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$recipe_id = $_GET['id'];

// Obtener la receta y los ingredientes actuales
$sql = "SELECT * FROM recipes WHERE id = :recipe_id AND created_by = :user_id";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':recipe_id', $recipe_id, PDO::PARAM_INT);
$stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$recipe = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$recipe) {
    die("Receta no encontrada o no tiene permiso para editarla.");
}

// Obtener los ingredientes asociados a la receta
$sql_ingredients = "SELECT ri.quantity, i.name 
                    FROM recipe_ingredients ri 
                    INNER JOIN ingredients i ON ri.ingredient_id = i.id 
                    WHERE ri.recipe_id = :recipe_id";
$stmt_ingredients = $conn->prepare($sql_ingredients);
$stmt_ingredients->bindParam(':recipe_id', $recipe_id, PDO::PARAM_INT);
$stmt_ingredients->execute();
$ingredients = $stmt_ingredients->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <title>Editar Receta</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>

<body>
    <div class="recipe-container">
        <h1>Editar Receta</h1>
        <form id="recipe-form" action="edit_recipe_action.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($recipe_id); ?>">

            <label for="title">Título:</label>
            <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($recipe['title']); ?>" required>

            <label for="description">Descripción:</label>
            <textarea id="description" name="description" required><?php echo htmlspecialchars($recipe['description']); ?></textarea>

            <label for="category">Categoría:</label>
            <select name="category" id="category" onchange="toggleIngredientField()" required>
                <option value="Vegano" <?php echo ($recipe['category'] == 'Vegano') ? 'selected' : ''; ?>>Vegano</option>
                <option value="Intolerante" <?php echo ($recipe['category'] == 'Intolerante') ? 'selected' : ''; ?>>Intolerante</option>
                <option value="Alergeno" <?php echo ($recipe['category'] == 'Alergeno') ? 'selected' : ''; ?>>Alergeno</option>
            </select>

            <div id="ingredient-field" style="display: none;">
                <label for="ingredient">Ingrediente (Intolerancia/Alergia):</label>
                <input type="text" id="ingredient" name="ingredient" value="<?php echo htmlspecialchars($recipe['ingredient'] ?? ''); ?>">
            </div>

            <label for="type">Tipo de receta:</label>
            <select name="type" id="type" required>
                <option value="desayuno" <?php echo ($recipe['type'] == 'desayuno') ? 'selected' : ''; ?>>Desayuno</option>
                <option value="comida" <?php echo ($recipe['type'] == 'comida') ? 'selected' : ''; ?>>Comida</option>
                <option value="cena" <?php echo ($recipe['type'] == 'cena') ? 'selected' : ''; ?>>Cena</option>
                <option value="postre" <?php echo ($recipe['type'] == 'postre') ? 'selected' : ''; ?>>Postre</option>
                <option value="aperitivo" <?php echo ($recipe['type'] == 'aperitivo') ? 'selected' : ''; ?>>Aperitivo</option>
                <option value="snack" <?php echo ($recipe['type'] == 'snack') ? 'selected' : ''; ?>>Snack</option>
            </select>

            <label for="ingredients">Ingredientes:</label>
            <div id="ingredients-container">
                <?php foreach ($ingredients as $ingredient): ?>
                    <div class="ingredient">
                        <input type="text" name="ingredients[][name]" placeholder="Ingrediente" value="<?php echo htmlspecialchars($ingredient['name']); ?>" required>
                        <input type="text" name="ingredients[][quantity]" placeholder="Cantidad" value="<?php echo htmlspecialchars($ingredient['quantity']); ?>" required>
                    </div>
                <?php endforeach; ?>
                <button type="button" id="add-ingredient">Agregar Ingrediente</button>
            </div>

            <label for="instructions">Instrucciones:</label>
            <textarea id="instructions" name="instructions" required><?php echo htmlspecialchars($recipe['instructions']); ?></textarea>

            <div class="media-container">
                <div class="media-item">
                    <label for="current-image">Imagen Actual:</label>
                    <?php if (!empty($recipe['image'])): ?>
                        <img src="<?php echo htmlspecialchars($recipe['image']); ?>" alt="Imagen de la receta" class="recipe-image">
                    <?php else: ?>
                        <p>No hay imagen disponible.</p>
                    <?php endif; ?>
                    <label for="image">Nueva Imagen (opcional):</label>
                    <input type="file" id="image" name="image">
                </div>

                <div class="media-item">
                    <label for="current-video">Video Actual:</label>
                    <?php if (!empty($recipe['video'])): ?>
                        <video controls class="recipe-video">
                            <source src="<?php echo htmlspecialchars($recipe['video']); ?>" type="video/mp4">
                            Tu navegador no soporta la reproducción de videos.
                        </video>
                    <?php else: ?>
                        <p>No hay video disponible.</p>
                    <?php endif; ?>
                    <label for="video">Nuevo Video (opcional):</label>
                    <input type="file" id="video" name="video">
                </div>
            </div>

            <button type="submit">Guardar Cambios</button>
        </form>
    </div>

    <script>
        function toggleIngredientField() {
            const category = document.getElementById('category').value;
            document.getElementById('ingredient-field').style.display = (category === 'Intolerante' || category === 'Alergeno') ? 'block' : 'none';
        }

        document.getElementById('add-ingredient').addEventListener('click', () => {
            const container = document.getElementById('ingredients-container');
            const newIngredient = document.createElement('div');
            newIngredient.classList.add('ingredient');
            newIngredient.innerHTML = `
                <input type="text" name="ingredients[][name]" placeholder="Ingrediente" required>
                <input type="text" name="ingredients[][quantity]" placeholder="Cantidad" required>
            `;
            container.appendChild(newIngredient);
        });

        function capitalizeFirstLetter(text) {
            return text.replace(/(?:^|\.\s*)([a-z])/g, function(match, p1) {
                return match.replace(p1, p1.toUpperCase());
            });
        }

        document.getElementById('recipe-form').addEventListener('submit', function(event) {
            const title = document.getElementById('title');
            const description = document.getElementById('description');
            const instructions = document.getElementById('instructions');

            title.value = capitalizeFirstLetter(title.value);
            description.value = capitalizeFirstLetter(description.value);
            instructions.value = capitalizeFirstLetter(instructions.value);

            const ingredientNames = document.querySelectorAll('input[name="ingredients[][name]"]');
            ingredientNames.forEach(input => {
                input.value = capitalizeFirstLetter(input.value);
            });
        });

        toggleIngredientField(); // Inicializar el estado del campo de ingrediente
    </script>
</body>
<?php include 'footer.php'; ?>
</html>